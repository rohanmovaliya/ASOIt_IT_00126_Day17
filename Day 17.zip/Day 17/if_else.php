<?php
$n = 15;
// echo $n;
echo "<br>";
if ($n % 2 ==0){
    echo ("$n is even number");
}
else{
    echo ("$n is odd number");
}
?>
    
