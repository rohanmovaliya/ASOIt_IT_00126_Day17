<?php
$name = "Rohan Movaliya";
$number = 25;
$num = 10.5;

echo $name;
echo "<br>";
echo $number;
echo "<br>";
echo $num;
?>