<h1><b><i><u>
<?php
$days = 5;
switch ($days) {
    case 1:
        echo "Monday";
        break;
    case 2:
        echo "Tuesdy";
        break;
    case 3:
        echo "Wednesday";
        break;
    case 4:
        echo "Thrusday";
        break;
    case 5:
        echo "Friday";
        break;
    case 6:
        echo "Saturday";
        break;
    case 7:
        echo "Sunday";
        break;
    
    default:
        echo "Invalid Input";
        break;
}
?>
</h1></u></i></b>