<h1>
    <?php
    $num1 = 15;
    $num2 = 5;
    echo " The sum of $num1 and $num2 is ", $num1 + $num2;
    ?>
</h1>