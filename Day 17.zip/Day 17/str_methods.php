<?PHP
$str = "Hello World!";
echo strlen($str);
?>