<?php
$cars = array("Chayan", "Dhruvi", "Dhruvil");
echo "<br>";
var_dump($cars);
echo "<br>";
echo $cars[0];
echo $cars[1];
echo $cars[2];


?>