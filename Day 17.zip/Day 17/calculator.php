<?PHP
$n1 = 10;
$n2 = 2;
echo "Addition of $n1 and $n2 is =  ", $n1 + $n2;
echo "<br>";
echo "Subtraction of $n1 from $n2 is =  ", $n1 - $n2;
echo "<br>";
echo "Multiplication of $n1 and $n2 is =  ", $n1 * $n2;
echo "<br>";
echo "Division of $n1 and $n2 is =  ", $n1 / $n2;
echo "<br>";
echo "Modulus of $n1 and $n2 is =  ", $n1 % $n2;
echo "<br>";
echo "Exponentiation of $n1 and $n2 is =  ", $n1 ** $n2;
echo "<br>";
?>