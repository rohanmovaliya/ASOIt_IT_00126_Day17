<h1>
    <?php
    echo "This is my first PHP Script.<br>";
    ?>
</h1>
<h2>
    <?php
    echo "Hello PHP. Now I work with you!!";
    ?>
</h2>